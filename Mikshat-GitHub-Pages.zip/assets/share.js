"use strict";
function parsePoint(search){
 const q=new URLSearchParams(search);if(q.getAll("ll").length!==1||q.getAll("n").length>1)return null;
 const ll=q.get("ll").split(",");if(ll.length!==2||ll.some(x=>!x.trim()))return null;
 const numeric=/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/;
 if(ll.some(x=>!numeric.test(x.trim())))return null;
 const lat=Number(ll[0]),lon=Number(ll[1]);if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return null;
 return {lat,lon,name:q.get("n")||"الموقع المحدد"};
}
if(typeof module!=="undefined")module.exports={parsePoint};
if(typeof document!=="undefined"){
 const p=parsePoint(location.search),byId=id=>document.getElementById(id);
 if(!p)byId("invalid").hidden=false;
 else{
  byId("point").hidden=false;byId("name").textContent=p.name;
  const ll=p.lat.toFixed(6)+", "+p.lon.toFixed(6);byId("coordinates").textContent=ll;
  byId("open").href="mikshat://map?ll="+p.lat+","+p.lon+"&n="+encodeURIComponent(p.name);
  byId("copy").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(ll);byId("status").textContent="تم نسخ الإحداثيات";}catch(e){const selection=getSelection(),range=document.createRange();range.selectNodeContents(byId("coordinates"));selection.removeAllRanges();selection.addRange(range);byId("status").textContent="تم تحديد الإحداثيات؛ اختر نسخ.";}});
 }
}
